from django.apps import AppConfig


class DiscussionBoardConfig(AppConfig):
    name = 'discussion_board'
